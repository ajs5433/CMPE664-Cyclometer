/*
 * magneticSensorAnalyzer.cpp
 *
 *  Created on: May 9, 2017
 *      Author: ajs5433
 */

#include <iostream>
#include "buttonInputAnalyzer.h"
#include <sys/neutrino.h>

void *buttonMode_thread(void *object){

}

void *buttonSet_thread(void *object){

}

class buttonInputAnalyzer
{
	display myDisplay;

	buttonInputAnalyzer(){
		int buttonMode;
		int buttonSet;

		buttonMode = ThreadCreate(0, &buttonMode_thread, NULL, NULL);
		buttonSet = ThreadCreate(0, &buttonSet_thread, NULL, NULL);
	}

	void assignDisplay(display d)
	{
		myDisplay = d;
		std::cout<<"printing"<<std::endl;
	}

};
