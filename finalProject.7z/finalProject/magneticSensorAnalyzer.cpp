/*
 * magneticSensorAnalyzer.cpp
 *
 *  Created on: May 9, 2017
 *      Author: ajs5433
 */

#include <iostream>
#include "magneticSensorAnalyzer.h"


class magneticSensorAnalyzer
{
	void test()
	{
		std::cout<<"printing"<<std::endl;
	}
};
