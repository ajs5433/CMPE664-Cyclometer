/*
 * magneticSensorAnalyzer.cpp
 *
 *  Created on: May 9, 2017
 *      Author: ajs5433
 */

#include <iostream>
#include "display.h"
#include <sys/neutrino.h>

#define displayValues	0
#define displayClock	1

void *ledPWM(void *object)
{

	return NULL;
}

class display
{
	int status = displayClock();

	display()
	{
		std::cout<<"creating display"<<std::endl;

		int frequency_thread;
		frequency_thread = ThreadCreate(0, &ledPWM, NULL, NULL);
	}

	void setDisplayMode(){

	}

	void setSpeed(){

	}

	void activateDisplay(){
		status = displayValues;
	}

};
